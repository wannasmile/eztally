This folder is for temporary binary and dcu files 
build by xmlrpc\build\BuildAll.bpg.